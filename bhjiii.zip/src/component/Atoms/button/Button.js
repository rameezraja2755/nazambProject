import * as React from 'react';
import Button from '@mui/material/Button';

export default function BasicButtons() {
  return (
      <Button variant="primary" style={{Width:"144px",Height:"40px",Top:"78px",Left:"13px",Radius:"8px"}}>sign in</Button>
  );
}

