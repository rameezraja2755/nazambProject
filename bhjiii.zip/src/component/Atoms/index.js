import React from 'react'
// import Input from '../Atoms/Input'

const index = () => {
  return (
    <div>
        {/* <Input/> */}
    </div>
  )
}

export default index