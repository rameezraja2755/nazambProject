import React from 'react'

const myFlat = () => {
  return (
    <div>myFlat</div>
  )
}

export default myFlat