import React from 'react'

const Chat = () => {
  return (
    <div>chat</div>
  )
}

export default Chat;