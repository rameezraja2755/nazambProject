import React from 'react';
//import NavbarBlue from '../../Organisms/Navbar_Blue';
//import Navbar from "../../Organisms/Navbar";
const home = () => {
  return (
   <>
{/* <Navbar /> */}
{/* <div>homeee</div> */}
{/* <NavbarBlue /> */}
   </>
  )
}

export default home;