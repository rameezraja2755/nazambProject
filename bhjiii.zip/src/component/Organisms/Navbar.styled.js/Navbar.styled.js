// import { styled } from '@mui/system';

// const NavbarLogo = styled("Boxes")({
//     display:"flex",
//     backgroundColor:"red"
 
// });

// export { Boxes};
